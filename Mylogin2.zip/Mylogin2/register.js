document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    localStorage.setItem(username, password,);
    alert('Registration successful! You can now login.');
    window.location.href = 'login.html';
});
