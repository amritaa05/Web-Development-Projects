localStorage.removeItem('loggedInUser');
alert('Congratulation on a successful logout! Your security is our top priority. Until we meet again,stay safe and secure.');
window.location.href = 'login.html';
